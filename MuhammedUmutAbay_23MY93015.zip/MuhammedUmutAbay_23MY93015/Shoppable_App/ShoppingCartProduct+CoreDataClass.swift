//
//  ShoppingCartProduct+CoreDataClass.swift
//  
//
//  Created by Cristina Dobson 
//
//

import Foundation
import CoreData

@objc(ShoppingCartProduct)
public class ShoppingCartProduct: NSManagedObject {

}
