//
//  ShoppingCart+CoreDataClass.swift
//
//
//  Created by Cristina Dobson 
//
//

import Foundation
import CoreData

@objc(ShoppingCart)
public class ShoppingCart: NSManagedObject {

}
